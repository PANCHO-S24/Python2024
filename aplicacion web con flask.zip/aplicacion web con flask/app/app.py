from flask import Flask, render_template, request
from datetime import datetime
from flask_sqlalchemy import SQLAlchemy
import os

app = Flask(__name__)
app.config.from_pyfile(os.path.join('C:\\Users\\pancho\\OneDrive\\Escritorio\\aplicacion web con flask\\app','config.py'))

from models import Repartidor,Sucursal,Transporte,Paquete

@app.route("/", methods=["GET", "POST"])
def login():
    return render_template('template_base.html')

@app.route('/sucursales', methods = ["GET", "POST"])
def lista_sucursales():
    try:
        sucursales = Sucursal.query.order_by(Sucursal.numero).all()
        print(f"Numero de sucursales obtenidas: {len(sucursales)}")
        return render_template('sucursales.html', sucursales=sucursales)
    except Exception as e:
        print(f"Error al obtener sucursales: {e}")
        return render_template('error.html')

"""@app.route('/registrar_paquete', methods=["GET", "POST"])
def registrar_paquete():
    if request.method == "POST":
        # Obtener los datos del formulario
        peso_paquete = request.form["peso_paquete"]
        nombre_destinatario = request.form["nombre_destinatario"]
        direccion_destinatario = request.form["direccion_destinatario"]
        sucursal_destino = request.form["sucursal_destino"]

        # Crear un nuevo paquete
        paquete = Paquete(peso_paquete, nombre_destinatario, direccion_destinatario, sucursal_destino)
        db.session.add(paquete)
        db.session.commit()

        # Mostrar un mensaje de éxito
        flash("Paquete registrado con éxito")
        return redirect(url_for("lista_paquetes"))
    return render_template("registrar_paquete.html")"""


if __name__ == '__main__':
   app.run(debug=True)