from claseEquipo import Equipo
import csv
from maquinariapesada import MaquinariaPesada
from herramientasElec import HerramientaElectrica
class GestorEquipo:
    __listaequipo=[]
    
    def __init__(self):
        self.__listaequipo=[]
    
    def agregarequipos(self,unequipo):
        self.__listaequipo.append(unequipo)
    
    def cargaequipo(self):
        archivo= open("equipos.csv", encoding="UTF-8")
        reader = csv.reader(archivo, delimiter=";")
        next(reader)
        for fila in reader:
            if fila[0] == "M":
                    marc = fila[1]
                    model = fila[2]
                    anio = fila[3]
                    tc = fila[4]
                    pot= fila[5]
                    capc = fila[6]
                    tarfD = fila[7]
                    cantdiasAlq = fila[8]
                    tipomaq= fila[9]
                    pesot= fila[10]
                    unequipo = MaquinariaPesada (marc, model, anio, tc,pot,capc,tarfD,cantdiasAlq,tipomaq,pesot)
                    self.agregarequipos(unequipo)
            elif fila[0] == "E":
                    marc = fila[1]
                    model = fila[2]
                    anio = fila[3]
                    tc = fila[4]
                    pot= fila[5]
                    capc = fila[6]
                    tarfD = fila[7]
                    cantdiasAlq = fila[8]
                    tipoherr = fila[9]
                    unequipo = HerramientaElectrica(marc, model, anio,tc,pot,capc,tarfD,cantdiasAlq,tipoherr)
                    self.agregarequipos(unequipo)
        archivo.close()
        i=0
        while i<len(self.__listaequipo):
            print(self.__listaequipo[i].getmarca())
            i=i+1

    def BuscarPosicion(self):
        try:
            posicion = int(input("Ingrese la posición de un equipo a buscar: "))
            if posicion < 0:
                raise ValueError("La posición debe ser un número entero positivo")
            if posicion < len(self.__listaequipo):
                if isinstance(self.__listaequipo[posicion], MaquinariaPesada):
                    print(f"La posición {posicion} es una Maquinaria Pesada.")
                elif isinstance(self.__listaequipo[posicion], HerramientaElectrica):
                    print(f"La posición {posicion} es una Herramienta eléctrica")
            else:
                raise IndexError("Índice fuera de rango")
        except ValueError as e:
            print(f"Error: {e}")
        except IndexError as e:
            print(f"Error: {e}")
    
    def contarHerrElec(self):
        anio = input("Ingrese año de fabricacion ")
        cont = 0
        i=0
        while i <len(self.__listaequipo):
            if isinstance(self.__listaequipo[i],HerramientaElectrica) and self.__listaequipo[i].getanio() == anio:
                cont+=1
            i+=1
        print(f"Se encontraron {cont} herramientas electricas fabricadas en el año {anio}")

    def mostrarcantidadMaquina(self):
        capacidad_carga = int(input("Ingrese la capacidad de carga: "))
        cont = 0
        for equipo in self.__listaequipo:
            if isinstance(equipo, MaquinariaPesada) and int(equipo.getcapacidadcarga()) <= capacidad_carga:
                cont += 1
        print(f"Se encontraron {cont} maquinarias pesadas con capacidad de carga menor o igual a {capacidad_carga}")

    def MostrarEquipos(self):
        i=0
        while i < len(self.__listaequipo):
            print("------------------------")
            print(f"Modelo: {self.__listaequipo[i].getmarca()}")
            print(f"Modelo: {self.__listaequipo[i].getmodelo()}")
            print(f"Año: {self.__listaequipo[i].getanio()}")
            print(f"tipo combustible: {self.__listaequipo[i].gettipocombustible()}")
            print(f"Potencia: {self.__listaequipo[i].getpotencia()}")
            print(f"capacidad de carga: {self.__listaequipo[i].getcapacidadcarga()}")

            if isinstance(self.__listaequipo[i], MaquinariaPesada):
               print(f"Tarifa: {self.__listaequipo[i].tarifamaquina()}")
            elif isinstance(self.__listaequipo[i], HerramientaElectrica):
               print(f"Tarifa: {self.__listaequipo[i].tarifaherramienta()}")
            i+=1
            