from gestorequipo import GestorEquipo
a = GestorEquipo()
def menu():
    a.cargaequipo()
    while True:
      
        print("\n--- MENÚ DE OPCIONES ---")
        print("1. Mostrar equipo por indice ")
        print("2. Contar herramientas electricas por año")
        print("3. Contar maquinarias pesadas por capacidad")
        print("4. Mostrar todos los equipos")
        print("5. Salir")
        opcion = input("Ingrese el número de la opción que desea realizar: ")
        
        if opcion == "1":
           a.BuscarPosicion()
        elif opcion == "2":
           a.contarHerrElec()
        elif opcion == '3':
           a.mostrarcantidadMaquina()
        elif opcion == "4":
           a.MostrarEquipos()
        elif opcion == "5":
            break
        else:
            print("Opción inválida")


if __name__ == "__main__":
    menu()