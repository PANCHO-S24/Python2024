from claseEquipo import Equipo

class MaquinariaPesada(Equipo):
    __tipomaquinaria="str"
    __pesoTon="int"

    def __init__(self,marca,modelo,anio,tipocombustible,potencia,capacidadcarga,tarifaalquilerdiario,cantdiasAlq,tipomaquinaria,pesoTon):
        super().__init__(marca,modelo,anio,tipocombustible,potencia,capacidadcarga,tarifaalquilerdiario,cantdiasAlq)
        self.__tipomaquinaria= tipomaquinaria
        self.__pesoTon = pesoTon

    def gettipomaquinaria(self):
        return self.__tipomaquinaria
    def getpesoton(self):
        return self.__pesoTon
    
    def tarifamaquina(self):
        if self.__pesoTon <= "10":
            return int(self.gettarifaalquilerdiario()) * int(self.getcantdiasAlq())
        elif self.__pesoTon > "10":
            return int(self.gettarifaalquilerdiario()) * int(self.getcantdiasAlq()) * 1.20
        

