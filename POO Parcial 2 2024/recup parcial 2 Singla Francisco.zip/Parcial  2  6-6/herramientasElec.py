from claseEquipo import Equipo
class HerramientaElectrica(Equipo):
    __tipoherramienta=""
    def __init__(self,marca,modelo,anio,tipocombustible,potencia,capacidadcarga,tarifaalquilerdiario,cantdiasAlq,tipoherramienta):
        super().__init__(marca,modelo,anio,tipocombustible,potencia,capacidadcarga,tarifaalquilerdiario,cantdiasAlq)
        self.__tipoherramienta=tipoherramienta
    
    def getTipoherramienta(self):
            return self.__tipoherramienta
    
    def tarifaherramienta(self):
        if self.__tipoherramienta == "bateria":
            return int(self.gettarifaalquilerdiario()) * int(self.getcantdiasAlq()) * 1.10
        elif self.__tipoherramienta == "cable":
            return int(self.gettarifaalquilerdiario()) * int(self.getcantdiasAlq()) 