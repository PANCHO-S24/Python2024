import abc
from abc import ABC

class Equipo(object):
    __marca="str"
    __modelo="str"
    __anio="str"
    __tipocombustible="str"
    __potencia="str"
    __capacidadcarga="int"
    __tarifaalquilerdiario=""
    __cantdiasAlq="int"

    def __init__(self,marca,modelo,anio,tipocombustible,potencia,capacidadcarga,tarifaalquilerdiario,cantdiasAlq):
        self.__marca=marca
        self.__modelo=modelo
        self.__anio=anio
        self.__tipocombustible=tipocombustible
        self.__potencia=potencia
        self.__capacidadcarga=capacidadcarga
        self.__tarifaalquilerdiario=tarifaalquilerdiario
        self.__cantdiasAlq=cantdiasAlq

    def getmarca(self):
        return self.__marca
    def getmodelo(self):
        return self.__modelo
    def getanio(self):
        return self.__anio
    def gettipocombustible(self):
        return self.__tipocombustible
    def getpotencia(self):
        return self.__potencia
    def getcapacidadcarga(self):
        return self.__capacidadcarga
    def gettarifaalquilerdiario(self):
        return self.__tarifaalquilerdiario
    def getcantdiasAlq(self):
        return self.__cantdiasAlq
    
    @abc.abstractmethod                                
    def tarifaalquiler():
        pass
    
