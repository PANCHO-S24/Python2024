from vehiculos import Vehiculo #importa la clase padre

class Vanes(Vehiculo):
    __tipoCarroceria= "str"

    def __init__(self,marca,modelo,anio,capacidad,num_plaza,km,tarifa,tipoCarroceria):   #todos los de clase padre + atrinutos clase hija
        super().__init__(marca,modelo,anio,capacidad,num_plaza,km,tarifa)  #solo los de la clase padre
        self.__tipoCarroceria=tipoCarroceria

    def getTipoServicio(self):
        return self.__tipoServicio
        
    def tarifaVan(self):
        if self.__tipoCarroceria == "minivan":
            return float(self.gettarifa()) * 0.9
        else:
            return float(self.gettarifa()) * 1.025 