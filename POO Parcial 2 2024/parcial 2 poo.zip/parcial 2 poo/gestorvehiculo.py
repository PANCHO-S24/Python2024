from vehiculos import Vehiculo
import csv
from claseAutobuses import Autobuses
from claseVanes import Vanes

class GestorVehiculo():
    def __init__(self):
        self.__listavehiculo = []

    def agregarvehiculo(self, unvehiculo):
        self.__listavehiculo.append(unvehiculo)
    
    def cargavehiculo(self):
        archivo= open("vehiculos.csv", encoding="UTF-8")
        reader = csv.reader(archivo, delimiter=";")
        next(reader)
        for fila in reader:
            if fila[0] == "A":   # recorre el primer indice del csv y se compara 
                    marc = fila[1]
                    model = fila[2]
                    an = fila[3]
                    cap = fila[4]
                    nump = fila[5]
                    km = fila[6]
                    tar = fila[7]
                    tipS = fila[8]  # se agrega el atributo tipo servicio propio de la clase autobuses        
                    tur = fila[9]   # se agrega el atributo turno propio de la clase autobuses
                    unvehiculo = Autobuses(marc, model, an, cap, nump, km, tar, tipS, tur)
                    self.agregarvehiculo(unvehiculo)
            elif fila[0] == "V":
                    marc = fila[1]
                    model = fila[2]
                    an = fila[3]
                    cap = fila[4]
                    nump = fila[5]
                    km = fila[6]
                    tar = fila[7]
                    tipC = fila[8]
                    unvehiculo = Vanes(marc, model, an, cap, nump, km, tar, tipC)
                    self.agregarvehiculo(unvehiculo)
        archivo.close()   #cerrar archivo
        i=0
        while i<len(self.__listavehiculo):
            print(self.__listavehiculo[i].getmarca())   #muestra archivo cargado
            i=i+1
    
    def agregaNuevoVehiculo(self):
        opcion = input("Ingrese el tipo que desee 1.autobus/ 2.van: ")
        if opcion == "1":
           marca = input("Ingrese marca ")
           modelo = input("Ingrese modelo ")
           anio = input("Ingrese año ")
           capacidad = input("Ingrese capacidad ")
           numpasajeros = input("Ingrese numero de pasajeros ")
           km = input("Ingrese km ")
           tarifa = input("Ingrese tarifa ")
           tipoServicio = input("Ingrese tipo de servicio ")
           turno = input("Ingrese turno ")
           autobus_nuevo = Autobuses(marca, modelo, anio, capacidad, numpasajeros, km, tarifa, tipoServicio, turno) #crea obejeto y lo manda a la lista autobuses
           self.agregarvehiculo(autobus_nuevo)
        elif opcion == "2":
                marca = input("Ingrese marca ")
                modelo = input("Ingrese modelo ")
                anio = input("Ingrese año ")
                capacidad = input("Ingrese capacidad ")
                numpasajeros = input("Ingrese numero de pasajeros ")
                km = input("Ingrese km ")
                tarifa = input("Ingrese tarifa ")
                tipoCarroceria = input ("ingres tipo de carroceria ")
                van_nuevo = Vanes(marca, modelo, anio, capacidad, numpasajeros, km, tarifa, tipoServicio, turno)
                self.agregarvehiculo(van_nuevo)
        
        i=0
        while i<len(self.__listavehiculo):
            print(self.__listavehiculo[i].getmarca())
            i=i+1

    def buscarPosicion(self):
        posicion = int(input("Ingrese la posicion de vehiculo a buscar "))
        i=0
        band = False
        while i < len(self.__listavehiculo) :
            if i == posicion:        
                band = True
                if isinstance(self.__listavehiculo[i],Autobuses):
                    print(f" La posicion {i} es un autobús.")
                elif isinstance(self.__listavehiculo[i], Vanes):
                    print(f"La posicion {i} es una van.")
                    print(self.__listavehiculo[i].getmarca())
                i+=1
            else:
                i+=1
                    
    def mostrarcantidad(self):
        i=0
        sumA=0
        sumV=0
        while i < len(self.__listavehiculo):
            if isinstance(self.__listavehiculo[i],Autobuses):
                sumA += 1
            elif isinstance(self.__listavehiculo[i], Vanes):
                sumV += 1
            i+=1
        print(f"La cantidad de Autobuses es {sumA}") 
        print(f"La cantidad de Vans es {sumV}")

    def Mostrardatos(self):
        i=0
        while i < len(self.__listavehiculo):
            print("------------------------")
            print(f"Modelo: {self.__listavehiculo[i].getmodelo()}")
            print(f"Año: {self.__listavehiculo[i].getanio()}")
            print(f"Capacidad: {self.__listavehiculo[i].getcapacidad()}")
            if isinstance(self.__listavehiculo[i], Autobuses):
               print(f"Tarifa: {self.__listavehiculo[i].tarifaAutobus()}")
            elif isinstance(self.__listavehiculo[i], Vanes):
               print(f"Tarifa: {self.__listavehiculo[i].tarifaVan()}")
            i+=1

