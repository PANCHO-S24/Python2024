from gestorvehiculo import GestorVehiculo   #importar gestor clase padre
a = GestorVehiculo()

def menu():
    a.cargavehiculo()
    while True:
      
        print("\n--- MENÚ DE OPCIONES ---")
        print("1. Agregar Vehiculos a la coleccion ")
        print("2. Mostrar tipo de vehiculo segun un indice")
        print("3. Mostrar cantidad de vehiculos de cada tipo ")
        print("5. Salir")
        opcion = input("Ingrese el número de la opción que desea realizar: ")
        
        if opcion == "1":
           a.agregaNuevoVehiculo()
        elif opcion == "2":
           a.buscarPosicion()
        elif opcion == '3':
           a.mostrarcantidad()
        elif opcion == "4":
           a.Mostrardatos()   
        elif opcion == "5":
            break
        else:
            print("Opción inválida")


if __name__ == "__main__":
    menu()