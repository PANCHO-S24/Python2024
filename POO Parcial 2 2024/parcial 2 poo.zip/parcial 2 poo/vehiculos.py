import abc
from abc import ABC

class Vehiculo(object):
    __marca= "str"
    __modelo= "str"
    __anio="str"
    __capacidad="int"
    __num_plaza="int"
    __km="flaot"
    __tarifa="float"

    def __init__(self,marca,modelo,anio,capacidad,num_plaza,km,tarifa):
        self.__marca=marca
        self.__modelo=modelo
        self.__anio=anio
        self.__capacidad=capacidad
        self.__num_plaza=num_plaza
        self.__km=km
        self.__tarifa=tarifa

    def getmarca(self):
        return self.__marca
    def getmodelo(self):
        return self.__modelo
    def getanio(self):
        return self.__anio
    def getcapacidad(self):
         return self.__capacidad
    def getnum_plaza(self):
        return self.__num_plaza
    def getkm(self):
        return self.__km
    def gettarifa(self):
        return self.__tarifa
    
    @abc.abstractmethod          #decorador                      
    def tarifaservicio():         
        pass                     #pass