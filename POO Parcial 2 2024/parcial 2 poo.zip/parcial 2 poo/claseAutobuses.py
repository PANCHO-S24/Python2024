from vehiculos import Vehiculo  #importa la clase padre

class Autobuses(Vehiculo):
    __tipoServicio="str"
    __turno="str"
    
    def __init__(self,marca,modelo,anio,capacidad,num_plaza,km,tarifa,tipoServicio,turno):
       super().__init__(marca,modelo,anio,capacidad,num_plaza,km,tarifa)
       self.__tipoServicio=tipoServicio
       self.__turno=turno
    
    def getTipoServicio(self):
        return self.__tipoServicio
    def getTurno(self):
        return self.__turno

    def tarifaAutobus(self):
        if self.__turno == "noche" and self.__tipoServicio == "turismo":
            return float(self.gettarifa()) * 1.2
        else:
            return float(self.gettarifa()) * 1.05 
